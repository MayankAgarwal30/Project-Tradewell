<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($review->product): ?>
        <tr>
            <td><?php echo e($key+1); ?></td>
            <td>
                                        <span class="d-block font-size-sm text-body">
                                            <a href="<?php echo e(route('admin.product.view',[$review['product_id']])); ?>">
                                                <?php echo e($review->product['name']); ?>

                                            </a>
                                        </span>
            </td>
            <td>
                <a href="<?php echo e(route('admin.customer.view',[$review->user_id])); ?>">
                    <?php echo e($review->customer->f_name." ".$review->customer->l_name); ?>

                </a>
            </td>
            <td>
                <?php echo e($review->comment); ?>

            </td>
            <td>
                <label class="badge badge-soft-info">
                    <?php echo e($review->rating); ?> <i class="tio-star"></i>
                </label>
            </td>
        </tr>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /opt/lampp/htdocs/grofresh/resources/views/admin-views/reviews/partials/_table.blade.php ENDPATH**/ ?>