<?php $__env->startSection('title','Add new Time Slot'); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><?php echo e(trans('messages.Time Slot')); ?></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <form action="<?php echo e(route('admin.timeSlot.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"> <?php echo e(trans('messages.Time')); ?> <?php echo e(trans('messages.Start')); ?> </label>
                                <input type="time" name="start_time" class="form-control" value="10:30:00"
                                       placeholder="Ex : 10:30 am" required>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"> <?php echo e(trans('messages.Time')); ?> <?php echo e(trans('messages.Ends')); ?> </label>
                                <input type="time" name="end_time" class="form-control" value="19:30:00" placeholder="5:45 pm"
                                       required>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary"><?php echo e(trans('messages.submit')); ?></button>
                </form>
            </div>

            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <hr>
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-header-title"></h5>
                    </div>
                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table id="columnSearchDatatable"
                               class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table"
                               data-hs-datatables-options='{
                                 "order": [],
                                 "orderCellsTop": true
                               }'>
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(trans('messages.#')); ?></th>

                                <th class="text-center"><?php echo e(trans('messages.Start')); ?> <?php echo e(trans('messages.Time')); ?> </th>
                                <th class="text-center"><?php echo e(trans('messages.End')); ?> <?php echo e(trans('messages.Time')); ?>  </th>
                                <th><?php echo e(trans('messages.status')); ?></th>
                                <th style="width: 100px"><?php echo e(trans('messages.action')); ?></th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $timeSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$timeSlot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>


                                    <td class="text-center" ><input style="background: white !important; border: none !important; " type="time" value="<?php echo e($timeSlot['start_time']); ?>" disabled> </td>
                                    <td class="text-center" ><input  style="background: white !important; border: none !important; "type="time" value="<?php echo e($timeSlot['end_time']); ?>" disabled></td>
                                    <td>
                                        <?php if($timeSlot['status']==1): ?>
                                            <div style="padding: 10px;border: 1px solid;cursor: pointer"
                                                 onclick="location.href='<?php echo e(route('admin.timeSlot.status',[$timeSlot['id'],0])); ?>'">
                                                <span class="legend-indicator bg-success"></span><?php echo e(trans('messages.active')); ?>

                                            </div>
                                        <?php else: ?>
                                            <div style="padding: 10px;border: 1px solid;cursor: pointer"
                                                 onclick="location.href='<?php echo e(route('admin.timeSlot.status',[$timeSlot['id'],1])); ?>'">
                                                <span class="legend-indicator bg-danger"></span><?php echo e(trans('messages.disabled')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <!-- Dropdown -->
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                    id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                                                    aria-expanded="false">
                                                <i class="tio-settings"></i>
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <a class="dropdown-item"
                                                   href="<?php echo e(route('admin.timeSlot.update',[$timeSlot['id']])); ?>"><?php echo e(trans('messages.edit')); ?></a>
                                                <a class="dropdown-item" href="javascript:"
                                                onclick="form_alert('timeSlot-<?php echo e($timeSlot['id']); ?>','Want to delete this Time Slot')"><?php echo e(trans('messages.delete')); ?>  </a>
                                                <form action="<?php echo e(route('admin.timeSlot.delete',[$timeSlot['id']])); ?>"
                                                      method="post" id="timeSlot-<?php echo e($timeSlot['id']); ?>">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                                </form>
                                            </div>
                                        </div>
                                        <!-- End Dropdown -->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End Table -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/grofresh/resources/views/admin-views/timeSlot/index.blade.php ENDPATH**/ ?>