<?php $__env->startSection('title','Update Branch'); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title text-capitalize"><i class="tio-edit"></i> <?php echo e(trans('messages.branch')); ?> <?php echo e(trans('messages.update')); ?></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <?php ($branch_count=\App\Model\Branch::count()); ?>
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <form action="<?php echo e(route('admin.branch.update',[$branch['id']])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.name')); ?></label>
                                <input type="text" name="name" value="<?php echo e($branch['name']); ?>" class="form-control" placeholder="New branch" required>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.email')); ?></label>
                                <input type="email" name="email" value="<?php echo e($branch['email']); ?>" class="form-control"
                                       placeholder="EX : example@example.com" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-5">
                            <div class="form-group">
                                <label class="input-label" for=""><?php echo e(trans('messages.latitude')); ?></label>
                                <input type="text" name="latitude" value="<?php echo e($branch['latitude']); ?>" class="form-control" placeholder="Ex : -132.44442"
                                       <?php echo e($branch_count>1?'required':''); ?>>
                            </div>
                        </div>
                        <div class="col-5">
                            <div class="form-group">
                                <label class="input-label" for=""><?php echo e(trans('messages.longitude')); ?></label>
                                <input type="text" name="longitude" value="<?php echo e($branch['longitude']); ?>" class="form-control" placeholder="Ex : 94.233"
                                    <?php echo e($branch_count>1?'required':''); ?>>
                            </div>
                        </div>
                        <div class="col-2">
                            <div class="form-group">
                                <label class="input-label" for="">
                                    <i class="tio-info-outined"
                                       data-toggle="tooltip"
                                       data-placement="top"
                                       title="This value is the radius from your restaurant location, and customer can order food inside  the circle calculated by this radius."></i>
                                    <?php echo e(trans('messages.coverage')); ?> ( <?php echo e(trans('messages.km')); ?> )
                                </label>
                                <input type="number" name="coverage" min="1" value="<?php echo e($branch['coverage']); ?>" max="1000" class="form-control" placeholder="Ex : 3"
                                    <?php echo e($branch_count>1?'required':''); ?>>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label class="input-label" for=""><?php echo e(trans('messages.address')); ?></label>
                                <input type="text" name="address" value="<?php echo e($branch['address']); ?>" class="form-control" placeholder="" required>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.password')); ?> <span class="" style="color: red;font-size: small">* ( input if you want to reset. )</span></label>
                                <input type="text" name="password" class="form-control" placeholder="">
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary"><?php echo e(trans('messages.update')); ?></button>
                </form>
            </div>
            <!-- End Table -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/grofresh/resources/views/admin-views/branch/edit.blade.php ENDPATH**/ ?>