<?php $__env->startSection('title','Add new coupon'); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><i class="tio-add-circle-outlined"></i> <?php echo e(trans('messages.add')); ?> <?php echo e(trans('messages.new')); ?> <?php echo e(trans('messages.coupon')); ?></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <form action="<?php echo e(route('admin.coupon.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                   <div class="row">
                       <div class="col-4">
                           <div class="form-group">
                               <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.title')); ?></label>
                               <input type="text" name="title" class="form-control" placeholder="New coupon" required>
                           </div>
                       </div>
                       <div class="col-4">
                           <div class="form-group">
                               <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.coupon')); ?> <?php echo e(trans('messages.type')); ?></label>
                               <select name="coupon_type" class="form-control" onchange="coupon_type_change(this.value)">
                                   <option value="default"><?php echo e(trans('messages.default')); ?></option>
<!--                                   <option value="first_order"><?php echo e(trans('messages.first')); ?> <?php echo e(trans('messages.order')); ?></option>-->
                               </select>
                           </div>
                       </div>
                       <div class="col-4" id="limit-for-user">
                           <div class="form-group">
                               <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.limit')); ?> <?php echo e(trans('messages.for')); ?> <?php echo e(trans('messages.same')); ?> <?php echo e(trans('messages.user')); ?></label>
                               <input type="number" name="limit" class="form-control" placeholder="EX: 10">
                           </div>
                       </div>
                   </div>

                    <div class="row">
                        <div class="col-md-4 col-6">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.code')); ?></label>
                                <input type="text" name="code" class="form-control"
                                       placeholder="<?php echo e(\Illuminate\Support\Str::random(8)); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-4 col-6">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.start')); ?> <?php echo e(trans('messages.date')); ?></label>
                                <input type="date" name="start_date" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-4 col-6">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.expire')); ?> <?php echo e(trans('messages.date')); ?></label>
                                <input type="date" name="expire_date" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-3 col-6">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.min')); ?> <?php echo e(trans('messages.purchase')); ?></label>
                                <input type="number" step="0.01" name="min_purchase" value="0" min="0" max="100000" class="form-control"
                                       placeholder="100">
                            </div>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.max')); ?> <?php echo e(trans('messages.discount')); ?></label>
                                <input type="number" step="0.01" min="0" value="0" max="1000000" name="max_discount" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-4 col-6">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.discount')); ?></label>
                                <input type="number" step="0.01" min="1" max="10000" name="discount" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-2 col-6">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.discount')); ?> <?php echo e(trans('messages.type')); ?></label>
                                <select name="discount_type" class="form-control">
                                    <option value="amount"><?php echo e(trans('messages.amount')); ?></option>
                                    <option value="percent"><?php echo e(trans('messages.percent')); ?></option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary"><?php echo e(trans('messages.submit')); ?></button>
                </form>
            </div>

            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <hr>
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-header-title"></h5>
                    </div>
                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table id="columnSearchDatatable"
                               class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table"
                               data-hs-datatables-options='{
                                 "order": [],
                                 "orderCellsTop": true
                               }'>
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(trans('messages.#')); ?></th>
                                <th><?php echo e(trans('messages.title')); ?></th>
                                <th><?php echo e(trans('messages.code')); ?></th>
                                <th><?php echo e(trans('messages.min')); ?> <?php echo e(trans('messages.purchase')); ?></th>
                                <th><?php echo e(trans('messages.max')); ?> <?php echo e(trans('messages.discount')); ?></th>
                                <th><?php echo e(trans('messages.discount')); ?></th>
                                <th><?php echo e(trans('messages.discount')); ?> <?php echo e(trans('messages.type')); ?></th>
                                <th><?php echo e(trans('messages.start')); ?> <?php echo e(trans('messages.date')); ?></th>
                                <th><?php echo e(trans('messages.expire')); ?> <?php echo e(trans('messages.date')); ?></th>
                                <th><?php echo e(trans('messages.status')); ?></th>
                                <th><?php echo e(trans('messages.action')); ?></th>
                            </tr>
                            <tr>
                                <th></th>
                                <th>
                                    <input type="text" id="column1_search" class="form-control form-control-sm"
                                           placeholder="<?php echo e(trans('messages.search')); ?>">
                                </th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th>
                                    
                                </th>
                                <th></th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td>
                                    <span class="d-block font-size-sm text-body">
                                        <?php echo e($coupon['title']); ?>

                                    </span>
                                    </td>
                                    <td><?php echo e($coupon['code']); ?></td>
                                    <td><?php echo e($coupon['min_purchase']." ".\App\CentralLogics\Helpers::currency_symbol()); ?></td>
                                    <td><?php echo e($coupon['max_discount']." ".\App\CentralLogics\Helpers::currency_symbol()); ?></td>
                                    <td><?php echo e($coupon['discount']); ?></td>
                                    <td><?php echo e($coupon['discount_type']); ?></td>
                                    <td><?php echo e($coupon['start_date']); ?></td>
                                    <td><?php echo e($coupon['expire_date']); ?></td>
                                    <td>
                                        <?php if($coupon['status']==1): ?>
                                            <div style="padding: 10px;border: 1px solid;cursor: pointer"
                                                 onclick="location.href='<?php echo e(route('admin.coupon.status',[$coupon['id'],0])); ?>'">
                                                <span class="legend-indicator bg-success"></span><?php echo e(trans('messages.active')); ?>

                                            </div>
                                        <?php else: ?>
                                            <div style="padding: 10px;border: 1px solid;cursor: pointer"
                                                 onclick="location.href='<?php echo e(route('admin.coupon.status',[$coupon['id'],1])); ?>'">
                                                <span class="legend-indicator bg-danger"></span><?php echo e(trans('messages.disabled')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <!-- Dropdown -->
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                    id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                                                    aria-expanded="false">
                                                <i class="tio-settings"></i>
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <a class="dropdown-item"
                                                   href="<?php echo e(route('admin.coupon.update',[$coupon['id']])); ?>"><?php echo e(trans('messages.edit')); ?></a>
                                                <a class="dropdown-item" href="javascript:"
                                                   onclick="form_alert('coupon-<?php echo e($coupon['id']); ?>','Want to delete this coupon ?')"><?php echo e(trans('messages.delete')); ?></a>
                                                <form action="<?php echo e(route('admin.coupon.delete',[$coupon['id']])); ?>"
                                                      method="post" id="coupon-<?php echo e($coupon['id']); ?>">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                                </form>
                                            </div>
                                        </div>
                                        <!-- End Dropdown -->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <hr>
                        <table>
                            <tfoot>
                            <?php echo $coupons->links(); ?>

                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End Table -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        $(document).on('ready', function () {
            // INITIALIZATION OF DATATABLES
            // =======================================================
            var datatable = $.HSCore.components.HSDatatables.init($('#columnSearchDatatable'));

            $('#column1_search').on('keyup', function () {
                datatable
                    .columns(1)
                    .search(this.value)
                    .draw();
            });


            $('#column3_search').on('change', function () {
                datatable
                    .columns(9)
                    .search(this.value)
                    .draw();
            });

            // INITIALIZATION OF SELECT2
            // =======================================================
            $('.js-select2-custom').each(function () {
                var select2 = $.HSCore.components.HSSelect2.init($(this));
            });
        });

        function coupon_type_change(order_type) {
            if(order_type=='first_order'){
                $('#limit-for-user').hide();
            }else{
                $('#limit-for-user').show();
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/grofresh/resources/views/admin-views/coupon/index.blade.php ENDPATH**/ ?>