<?php $__env->startSection('title','FCM Settings'); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><?php echo e(trans('messages.firebase')); ?> <?php echo e(trans('messages.push')); ?> <?php echo e(trans('messages.notification')); ?> <?php echo e(trans('messages.setup')); ?></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(env('APP_MODE')!='demo'?route('admin.business-settings.update-fcm'):'javascript:'); ?>" method="post"
                              enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php ($key=\App\Model\BusinessSetting::where('key','push_notification_key')->first()->value); ?>
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(trans('messages.server')); ?> <?php echo e(trans('messages.key')); ?></label>
                                <textarea name="push_notification_key" class="form-control"
                                          required><?php echo e(env('APP_MODE')!='demo'?$key:''); ?></textarea>
                            </div>

                            <div class="row" style="display: none">
                                <?php ($project_id=\App\Model\BusinessSetting::where('key','fcm_project_id')->first()->value); ?>
                                <div class="col-md-12 col-12">
                                    <div class="form-group">
                                        <label class="input-label" for="exampleFormControlInput1">FCM Project ID</label>
                                        <input type="text" value="<?php echo e($project_id); ?>"
                                               name="fcm_project_id" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <button type="<?php echo e(env('APP_MODE')!='demo'?'submit':'button'); ?>" onclick="<?php echo e(env('APP_MODE')!='demo'?'':'call_demo()'); ?>" class="btn btn-primary"><?php echo e(trans('messages.submit')); ?></button>
                        </form>
                    </div>
                </div>
            </div>

            <hr>
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">

                <div class="card">
                    <div class="card-header">
                        <h2><?php echo e(trans('messages.push')); ?> <?php echo e(trans('messages.messages')); ?></h2>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.business-settings.update-fcm-messages')); ?>" method="post"
                              enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="row">
                                <?php ($opm=\App\Model\BusinessSetting::where('key','order_pending_message')->first()->value); ?>
                                <?php ($data=json_decode($opm,true)); ?>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label class="toggle-switch d-flex align-items-center mb-3"
                                               for="pending_status">
                                            <input type="checkbox" name="pending_status" class="toggle-switch-input"
                                                   value="1" id="pending_status" <?php echo e($data['status']==1?'checked':''); ?>>
                                            <span class="toggle-switch-label">
                                                <span class="toggle-switch-indicator"></span>
                                              </span>
                                            <span class="toggle-switch-content">
                                            <span class="d-block"><?php echo e(trans('messages.order')); ?> <?php echo e(trans('messages.pending')); ?> <?php echo e(trans('messages.message')); ?></span>
                                          </span>
                                        </label>
                                        <textarea name="pending_message"
                                                  class="form-control"><?php echo e($data['message']); ?></textarea>
                                    </div>
                                </div>

                                <?php ($ocm=\App\Model\BusinessSetting::where('key','order_confirmation_msg')->first()->value); ?>
                                <?php ($data=json_decode($ocm,true)); ?>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label class="toggle-switch d-flex align-items-center mb-3"
                                               for="confirm_status">
                                            <input type="checkbox" name="confirm_status" class="toggle-switch-input"
                                                   value="1" id="confirm_status" <?php echo e($data['status']==1?'checked':''); ?>>
                                            <span class="toggle-switch-label">
                                                <span class="toggle-switch-indicator"></span>
                                              </span>
                                            <span class="toggle-switch-content">
                                                <span class="d-block"> <?php echo e(trans('messages.order')); ?> <?php echo e(trans('messages.confirmation')); ?> <?php echo e(trans('messages.message')); ?></span>
                                              </span>
                                        </label>

                                        <textarea name="confirm_message"
                                                  class="form-control"><?php echo e($data['message']); ?></textarea>
                                    </div>
                                </div>

                                <?php ($oprm=\App\Model\BusinessSetting::where('key','order_processing_message')->first()->value); ?>
                                <?php ($data=json_decode($oprm,true)); ?>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label class="toggle-switch d-flex align-items-center mb-3"
                                               for="processing_status">
                                            <input type="checkbox" name="processing_status"
                                                   class="toggle-switch-input"
                                                   value="1" id="processing_status" <?php echo e($data['status']==1?'checked':''); ?>>
                                            <span class="toggle-switch-label">
                                                <span class="toggle-switch-indicator"></span>
                                              </span>
                                            <span class="toggle-switch-content">
                                                <span class="d-block"><?php echo e(trans('messages.order')); ?> <?php echo e(trans('messages.processing')); ?> <?php echo e(trans('messages.message')); ?></span>
                                              </span>
                                        </label>

                                        <textarea name="processing_message"
                                                  class="form-control"><?php echo e($data['message']); ?></textarea>
                                    </div>
                                </div>

                                <?php ($ofdm=\App\Model\BusinessSetting::where('key','out_for_delivery_message')->first()->value); ?>
                                <?php ($data=json_decode($ofdm,true)); ?>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label class="toggle-switch d-flex align-items-center mb-3"
                                               for="out_for_delivery">
                                            <input type="checkbox" name="out_for_delivery_status"
                                                   class="toggle-switch-input"
                                                   value="1" id="out_for_delivery" <?php echo e($data['status']==1?'checked':''); ?>>
                                            <span class="toggle-switch-label">
                                                <span class="toggle-switch-indicator"></span>
                                              </span>
                                            <span class="toggle-switch-content">
                                                <span class="d-block"><?php echo e(trans('messages.order')); ?> <?php echo e(trans('messages.out_for_delivery')); ?> <?php echo e(trans('messages.message')); ?></span>
                                              </span>
                                        </label>
                                        <textarea name="out_for_delivery_message"
                                                  class="form-control"><?php echo e($data['message']); ?></textarea>
                                    </div>
                                </div>

                                <?php ($odm=\App\Model\BusinessSetting::where('key','order_delivered_message')->first()->value); ?>
                                <?php ($data=json_decode($odm,true)); ?>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label class="toggle-switch d-flex align-items-center mb-3"
                                               for="delivered_status">
                                            <input type="checkbox" name="delivered_status"
                                                   class="toggle-switch-input"
                                                   value="1" id="delivered_status" <?php echo e($data['status']==1?'checked':''); ?>>
                                            <span class="toggle-switch-label">
                                                <span class="toggle-switch-indicator"></span>
                                              </span>
                                            <span class="toggle-switch-content">
                                                <span class="d-block"><?php echo e(trans('messages.order')); ?> <?php echo e(trans('messages.delivered')); ?> <?php echo e(trans('messages.message')); ?></span>
                                              </span>
                                        </label>

                                        <textarea name="delivered_message"
                                                  class="form-control"><?php echo e($data['message']); ?></textarea>
                                    </div>
                                </div>

                                <?php ($dba=\App\Model\BusinessSetting::where('key','delivery_boy_assign_message')->first()->value); ?>
                                <?php ($data=json_decode($dba,true)); ?>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">

                                        <label class="toggle-switch d-flex align-items-center mb-3"
                                               for="delivery_boy_assign">
                                            <input type="checkbox" name="delivery_boy_assign_status"
                                                   class="toggle-switch-input"
                                                   value="1"
                                                   id="delivery_boy_assign" <?php echo e($data['status']==1?'checked':''); ?>>
                                            <span class="toggle-switch-label">
                                                <span class="toggle-switch-indicator"></span>
                                              </span>
                                            <span class="toggle-switch-content">
                                                <span class="d-block"><?php echo e(trans('messages.deliveryman')); ?> <?php echo e(trans('messages.assign')); ?> <?php echo e(trans('messages.message')); ?></span>
                                              </span>
                                        </label>

                                        <textarea name="delivery_boy_assign_message"
                                                  class="form-control"><?php echo e($data['message']); ?></textarea>
                                    </div>
                                </div>

                                <?php ($dbs=\App\Model\BusinessSetting::where('key','delivery_boy_start_message')->first()->value); ?>
                                <?php ($data=json_decode($dbs,true)); ?>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label class="toggle-switch d-flex align-items-center mb-3"
                                               for="delivery_boy_start_status">
                                            <input type="checkbox" name="delivery_boy_start_status"
                                                   class="toggle-switch-input"
                                                   value="1"
                                                   id="delivery_boy_start_status" <?php echo e($data['status']==1?'checked':''); ?>>
                                            <span class="toggle-switch-label">
                                                <span class="toggle-switch-indicator"></span>
                                              </span>
                                            <span class="toggle-switch-content">
                                                <span class="d-block"> <?php echo e(trans('messages.deliveryman')); ?> <?php echo e(trans('messages.start')); ?> <?php echo e(trans('messages.message')); ?></span>
                                              </span>
                                        </label>

                                        <textarea name="delivery_boy_start_message"
                                                  class="form-control"><?php echo e($data['message']); ?></textarea>
                                    </div>
                                </div>

                                <?php ($dbc=\App\Model\BusinessSetting::where('key','delivery_boy_delivered_message')->first()->value); ?>
                                <?php ($data=json_decode($dbc,true)); ?>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">

                                        <label class="toggle-switch d-flex align-items-center mb-3"
                                               for="delivery_boy_delivered">
                                            <input type="checkbox" name="delivery_boy_delivered_status"
                                                   class="toggle-switch-input"
                                                   value="1"
                                                   id="delivery_boy_delivered" <?php echo e($data['status']==1?'checked':''); ?>>
                                            <span class="toggle-switch-label">
                                                <span class="toggle-switch-indicator"></span>
                                              </span>
                                            <span class="toggle-switch-content">
                                                <span class="d-block"><?php echo e(trans('messages.deliveryman')); ?> <?php echo e(trans('messages.delivered')); ?> <?php echo e(trans('messages.message')); ?></span>
                                              </span>
                                        </label>

                                        <textarea name="delivery_boy_delivered_message"
                                                  class="form-control"><?php echo e($data['message']); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <button type="submit" class="btn btn-primary"><?php echo e(trans('messages.submit')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#viewer').attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#customFileEg1").change(function () {
            readURL(this);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/grofresh/resources/views/admin-views/business-settings/fcm-index.blade.php ENDPATH**/ ?>