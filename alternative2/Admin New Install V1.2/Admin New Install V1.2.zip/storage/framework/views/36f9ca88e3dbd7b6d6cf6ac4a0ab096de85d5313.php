<?php $__env->startSection('title','Settings'); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><?php echo e(trans('messages.restaurant')); ?> <?php echo e(trans('messages.setup')); ?></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <form action="<?php echo e(route('admin.business-settings.update-setup')); ?>" method="post"
                      enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php ($name=\App\Model\BusinessSetting::where('key','restaurant_name')->first()->value); ?>
                    <div class="row">
                        <div class="col-md-6 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.restaurant')); ?> <?php echo e(trans('messages.name')); ?></label>
                                <input type="text" name="restaurant_name" value="<?php echo e($name); ?>" class="form-control"
                                       placeholder="New Restaurant" required>
                            </div>
                        </div>
                        <?php ($currency_code=\App\Model\BusinessSetting::where('key','currency')->first()->value); ?>
                        <div class="col-md-6 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.currency')); ?></label>
                                <select name="currency" class="form-control js-select2-custom">
                                    <?php $__currentLoopData = \App\Model\Currency::orderBy('currency_code')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($currency['currency_code']); ?>" <?php echo e($currency_code==$currency['currency_code']?'selected':''); ?>>
                                            <?php echo e($currency['currency_code']); ?> ( <?php echo e($currency['currency_symbol']); ?> )
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <?php ($phone=\App\Model\BusinessSetting::where('key','phone')->first()->value); ?>
                        <div class="col-md-4 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.phone')); ?></label>
                                <input type="text" value="<?php echo e($phone); ?>"
                                       name="phone" class="form-control"
                                       placeholder="" required>
                            </div>
                        </div>
                        <?php ($email=\App\Model\BusinessSetting::where('key','email_address')->first()->value); ?>
                        <div class="col-md-4 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.email')); ?></label>
                                <input type="email" value="<?php echo e($email); ?>"
                                       name="email" class="form-control" placeholder=""
                                       required>
                            </div>
                        </div>
                        <?php ($address=\App\Model\BusinessSetting::where('key','address')->first()->value); ?>
                        <div class="col-md-4 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.address')); ?></label>
                                <input type="text" value="<?php echo e($address); ?>"
                                       name="address" class="form-control" placeholder=""
                                       required>
                            </div>
                        </div>

                        <?php ($mov=\App\Model\BusinessSetting::where('key','minimum_order_value')->first()->value); ?>
                        <div class="col-md-6 col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.min')); ?> <?php echo e(trans('messages.order')); ?> <?php echo e(trans('messages.value')); ?> ( <?php echo e(\App\CentralLogics\Helpers::currency_symbol()); ?> )</label>
                                <input type="number" min="1" value="<?php echo e($mov); ?>"
                                       name="minimum_order_value" class="form-control" placeholder=""
                                       required>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <?php ($sp=\App\Model\BusinessSetting::where('key','self_pickup')->first()->value); ?>
                            <div class="form-group">
                                <label><?php echo e(trans('messages.self_pickup')); ?></label><small style="color: red">*</small>
                                <div class="input-group input-group-md-down-break">
                                    <!-- Custom Radio -->
                                    <div class="form-control">
                                        <div class="custom-control custom-radio">
                                            <input type="radio" class="custom-control-input" value="1" name="self_pickup"
                                                   id="sp1" <?php echo e($sp==1?'checked':''); ?>>
                                            <label class="custom-control-label" for="sp1"><?php echo e(trans('messages.on')); ?></label>
                                        </div>
                                    </div>
                                    <!-- End Custom Radio -->

                                    <!-- Custom Radio -->
                                    <div class="form-control">
                                        <div class="custom-control custom-radio">
                                            <input type="radio" class="custom-control-input" value="0" name="self_pickup"
                                                   id="sp2" <?php echo e($sp==0?'checked':''); ?>>
                                            <label class="custom-control-label" for="sp2"><?php echo e(trans('messages.off')); ?></label>
                                        </div>
                                    </div>
                                    <!-- End Custom Radio -->
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 col-12">
                            <?php ($delivery=\App\Model\BusinessSetting::where('key','delivery_charge')->first()->value); ?>
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.delivery')); ?> <?php echo e(trans('messages.charge')); ?></label>
                                <input type="number" min="1" name="delivery_charge" value="<?php echo e($delivery); ?>"
                                       class="form-control" placeholder="100" required>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <?php ($ev=\App\Model\BusinessSetting::where('key','email_verification')->first()->value); ?>
                            <div class="form-group">
                                <label><?php echo e(trans('messages.email')); ?> <?php echo e(trans('messages.verification')); ?></label><small style="color: red">*</small>
                                <div class="input-group input-group-md-down-break">
                                    <!-- Custom Radio -->
                                    <div class="form-control">
                                        <div class="custom-control custom-radio">
                                            <input type="radio" class="custom-control-input" value="1" name="email_verification"
                                                   id="ev1" <?php echo e($ev==1?'checked':''); ?>>
                                            <label class="custom-control-label" for="ev1"><?php echo e(trans('messages.on')); ?></label>
                                        </div>
                                    </div>
                                    <!-- End Custom Radio -->

                                    <!-- Custom Radio -->
                                    <div class="form-control">
                                        <div class="custom-control custom-radio">
                                            <input type="radio" class="custom-control-input" value="0" name="email_verification"
                                                   id="ev2" <?php echo e($ev==0?'checked':''); ?>>
                                            <label class="custom-control-label" for="ev2"><?php echo e(trans('messages.off')); ?></label>
                                        </div>
                                    </div>
                                    <!-- End Custom Radio -->
                                </div>
                            </div>
                        </div>

                        <?php ($footer_text=\App\Model\BusinessSetting::where('key','footer_text')->first()->value); ?>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="input-label" for="exampleFormControlInput1"><?php echo e(trans('messages.footer')); ?> <?php echo e(trans('messages.text')); ?></label>
                                <input type="text" value="<?php echo e($footer_text); ?>"
                                       name="footer_text" class="form-control" placeholder=""
                                       required>
                            </div>
                        </div>
                    </div>

                    <?php ($logo=\App\Model\BusinessSetting::where('key','logo')->first()->value); ?>
                    <div class="form-group">
                        <label><?php echo e(trans('messages.logo')); ?></label><small style="color: red">* ( <?php echo e(trans('messages.ratio')); ?> 3:1 )</small>
                        <div class="custom-file">
                            <input type="file" name="logo" id="customFileEg1" class="custom-file-input"
                                   accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                            <label class="custom-file-label" for="customFileEg1"><?php echo e(trans('messages.choose')); ?> <?php echo e(trans('messages.file')); ?></label>
                        </div>
                        <hr>
                        <center>
                            <img style="height: 100px;border: 1px solid; border-radius: 10px;" id="viewer"
                                 onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img2.jpg')); ?>'"
                                 src="<?php echo e(asset('storage/app/public/restaurant/'.$logo)); ?>" alt="logo image"/>
                        </center>
                    </div>
                    <hr>
                    <button type="submit" class="btn btn-primary"><?php echo e(trans('messages.submit')); ?></button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#viewer').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#customFileEg1").change(function () {
            readURL(this);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/grofresh/resources/views/admin-views/business-settings/restaurant-index.blade.php ENDPATH**/ ?>