<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($key+1); ?></td>
        <td>
                                        <span class="d-block font-size-sm text-body">
                                             <a href="<?php echo e(route('admin.product.view',[$product['id']])); ?>">
                                               <?php echo e(substr($product['name'],0,20)); ?><?php echo e(strlen($product['name'])>20?'...':''); ?>

                                             </a>
                                        </span>
        </td>
        <td>
            <div style="height: 100px; width: 100px; overflow-x: hidden;overflow-y: hidden">
                <img
                    src="<?php echo e(asset('storage/app/public/product')); ?>/<?php echo e(json_decode($product['image'],true)[0]); ?>"
                    style="width: 100px"
                    onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img2.jpg')); ?>'">
            </div>
        </td>
        <td>
            <?php if($product['status']==1): ?>
                <div style="padding: 10px;border: 1px solid;cursor: pointer"
                     onclick="location.href='<?php echo e(route('admin.product.status',[$product['id'],0])); ?>'">
                                                <span
                                                    class="legend-indicator bg-success"></span><?php echo e(trans('messages.active')); ?>

                </div>
            <?php else: ?>
                <div style="padding: 10px;border: 1px solid;cursor: pointer"
                     onclick="location.href='<?php echo e(route('admin.product.status',[$product['id'],1])); ?>'">
                                                <span
                                                    class="legend-indicator bg-danger"></span><?php echo e(trans('messages.disabled')); ?>

                </div>
            <?php endif; ?>
        </td>
        <td>
            <label class="switch ml-2">
                <input type="checkbox" class="status"
                       onchange="daily_needs('<?php echo e($product['id']); ?>','<?php echo e($product->daily_needs==1?0:1); ?>')"
                       id="<?php echo e($product['id']); ?>" <?php echo e($product->daily_needs == 1?'checked':''); ?>>
                <span class="slider round"></span>
            </label>
        </td>
        <td><?php echo e($product['price']." ".\App\CentralLogics\Helpers::currency_symbol()); ?></td>
        <td>
            <label class="badge badge-soft-info"><?php echo e($product['total_stock']); ?></label>
        </td>
        <td>
            <!-- Dropdown -->
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" type="button"
                        id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">
                    <i class="tio-settings"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item"
                       href="<?php echo e(route('admin.product.edit',[$product['id']])); ?>"><?php echo e(trans('messages.edit')); ?></a>
                    <a class="dropdown-item" href="javascript:"
                       onclick="form_alert('product-<?php echo e($product['id']); ?>','Want to delete this item ?')"><?php echo e(trans('messages.delete')); ?></a>
                    <form action="<?php echo e(route('admin.product.delete',[$product['id']])); ?>"
                          method="post" id="product-<?php echo e($product['id']); ?>">
                        <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                    </form>
                </div>
            </div>
            <!-- End Dropdown -->
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /opt/lampp/htdocs/grofresh/resources/views/admin-views/product/partials/_table.blade.php ENDPATH**/ ?>