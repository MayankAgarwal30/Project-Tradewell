<?php if(!empty($orders) && $orders->count()): ?>
<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr class="status-<?php echo e($order['order_status']); ?> class-all">
        <td class="">
            <?php echo e($key+1); ?>

        </td>
        <td class="table-column-pl-0">
            <a href="<?php echo e(route('admin.orders.details',['id'=>$order['id']])); ?>"><?php echo e($order['id']); ?></a>
        </td>
        <td><?php echo e(date('d M Y',strtotime($order['delivery_date']))); ?></td>
        <td>
           <span><?php echo e($order->time_slot?$order->time_slot['start_time'].' - ' .$order->time_slot['end_time'] :'No Time Slot'); ?></span>
        
        </td>
        <td>
            <?php if($order->customer): ?>
                <a class="text-body text-capitalize"
                   href="<?php echo e(route('admin.customer.view',[$order['user_id']])); ?>"><?php echo e($order->customer['f_name'].' '.$order->customer['l_name']); ?></a>
            <?php else: ?>
                <label class="badge badge-danger"><?php echo e(trans('messages.invalid')); ?> <?php echo e(trans('messages.customer')); ?> <?php echo e(trans('messages.data')); ?></label>
            <?php endif; ?>
        </td>
        
        <td><?php echo e($order['order_amount'] ." ". \App\CentralLogics\Helpers::currency_symbol()); ?></td>
        <td class="text-capitalize">
            <?php if($order['order_status']=='pending'): ?>
                <span class="badge badge-soft-info ml-2 ml-sm-3">
                                      <span class="legend-indicator bg-info"></span><?php echo e(trans('messages.pending')); ?>

                                    </span>
            <?php elseif($order['order_status']=='confirmed'): ?>
                <span class="badge badge-soft-info ml-2 ml-sm-3">
                                      <span class="legend-indicator bg-info"></span><?php echo e(trans('messages.confirmed')); ?>

                                    </span>
            <?php elseif($order['order_status']=='processing'): ?>
                <span class="badge badge-soft-warning ml-2 ml-sm-3">
                                      <span class="legend-indicator bg-warning"></span><?php echo e(trans('messages.processing')); ?>

                                    </span>
            <?php elseif($order['order_status']=='out_for_delivery'): ?>
                <span class="badge badge-soft-warning ml-2 ml-sm-3">
                                      <span class="legend-indicator bg-warning"></span><?php echo e(trans('messages.out_for_delivery')); ?>

                                    </span>
            <?php elseif($order['order_status']=='delivered'): ?>
                <span class="badge badge-soft-success ml-2 ml-sm-3">
                                      <span class="legend-indicator bg-success"></span><?php echo e(trans('messages.delivered')); ?>

                                    </span>
            <?php else: ?>
                <span class="badge badge-soft-danger ml-2 ml-sm-3">
                                      <span class="legend-indicator bg-danger"></span><?php echo e(str_replace('_',' ',$order['order_status'])); ?>

                                    </span>
            <?php endif; ?>
        </td>
        <td>
            <div class="dropdown">
                <button class="btn btn-outline-secondary dropdown-toggle" type="button"
                        id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">
                    <i class="tio-settings"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item"
                       href="<?php echo e(route('admin.orders.details',['id'=>$order['id']])); ?>"><i
                            class="tio-visible"></i> <?php echo e(trans('messages.view')); ?></a>
                    <a class="dropdown-item" target="_blank"
                       href="<?php echo e(route('admin.orders.generate-invoice',[$order['id']])); ?>"><i
                            class="tio-download"></i> <?php echo e(trans('messages.invoice')); ?></a>
                </div>
            </div>
        </td>
    </tr>
   

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<tr>
<td colspan="4">No data found.</td>
</tr>
<?php endif; ?>


<?php /**PATH /opt/lampp/htdocs/grofresh/resources/views/admin-views/order/partials/_table.blade.php ENDPATH**/ ?>