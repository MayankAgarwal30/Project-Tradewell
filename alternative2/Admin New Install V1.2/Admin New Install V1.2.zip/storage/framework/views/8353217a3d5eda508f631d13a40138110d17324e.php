<?php $__env->startSection('title','Payment Setup'); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><?php echo e(trans('messages.payment')); ?> <?php echo e(trans('messages.gateway')); ?> <?php echo e(trans('messages.setup')); ?></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row" style="padding-bottom: 20px">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body" style="padding: 20px">
                        <h5 class="text-center"><?php echo e(trans('messages.payment')); ?> <?php echo e(trans('messages.method')); ?></h5>
                        <?php ($config=\App\CentralLogics\Helpers::get_business_settings('cash_on_delivery')); ?>
                        <form action="<?php echo e(route('admin.business-settings.payment-method-update',['cash_on_delivery'])); ?>"
                              method="post">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($config)): ?>
                                <div class="form-group mb-2">
                                    <label class="control-label"><?php echo e(trans('messages.cash_on_delivery')); ?></label>
                                </div>
                                <div class="form-group mb-2 mt-2">
                                    <input type="radio" name="status" value="1" <?php echo e($config['status']==1?'checked':''); ?>>
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.active')); ?></label>
                                    <br>
                                </div>
                                <div class="form-group mb-2">
                                    <input type="radio" name="status" value="0" <?php echo e($config['status']==0?'checked':''); ?>>
                                    <label
                                        style="padding-left: 10px"><?php echo e(trans('messages.inactive')); ?></label>
                                    <br>
                                </div>
                                <button type="submit" class="btn btn-primary mb-2"><?php echo e(trans('messages.save')); ?></button>
                            <?php else: ?>
                                <button type="submit" class="btn btn-primary mb-2"><?php echo e(trans('messages.configure')); ?></button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body" style="padding: 20px">
                        <h5 class="text-center"><?php echo e(trans('messages.payment')); ?> <?php echo e(trans('messages.method')); ?></h5>
                        <?php ($config=\App\CentralLogics\Helpers::get_business_settings('digital_payment')); ?>
                        <form action="<?php echo e(route('admin.business-settings.payment-method-update',['digital_payment'])); ?>"
                              method="post">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($config)): ?>
                                <div class="form-group mb-2">
                                    <label class="control-label"><?php echo e(trans('messages.digital')); ?> <?php echo e(trans('messages.payment')); ?></label>
                                </div>
                                <div class="form-group mb-2 mt-2">
                                    <input type="radio" name="status" value="1" <?php echo e($config['status']==1?'checked':''); ?>>
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.active')); ?></label>
                                    <br>
                                </div>
                                <div class="form-group mb-2">
                                    <input type="radio" name="status" value="0" <?php echo e($config['status']==0?'checked':''); ?>>
                                    <label
                                        style="padding-left: 10px"><?php echo e(trans('messages.inactive')); ?></label>
                                    <br>
                                </div>
                                <button type="submit" class="btn btn-primary mb-2"><?php echo e(trans('messages.save')); ?></button>
                            <?php else: ?>
                                <button type="submit" class="btn btn-primary mb-2"><?php echo e(trans('messages.configure')); ?></button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="row" style="padding-bottom: 20px">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body" style="padding: 20px">
                        <h5 class="text-center"><?php echo e(trans('messages.sslcommerz')); ?></h5>
                        <?php ($config=\App\CentralLogics\Helpers::get_business_settings('ssl_commerz_payment')); ?>
                        <form
                            action="<?php echo e(env('APP_MODE')!='demo'?route('admin.business-settings.payment-method-update',['ssl_commerz_payment']):'javascript:'); ?>"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($config)): ?>
                                <div class="form-group mb-2">
                                    <label
                                        class="control-label"><?php echo e(trans('messages.sslcommerz')); ?> <?php echo e(trans('messages.payment')); ?></label>
                                </div>
                                <div class="form-group mb-2 mt-2">
                                    <input type="radio" name="status" value="1" <?php echo e($config['status']==1?'checked':''); ?>>
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.active')); ?></label>
                                    <br>
                                </div>
                                <div class="form-group mb-2">
                                    <input type="radio" name="status" value="0" <?php echo e($config['status']==0?'checked':''); ?>>
                                    <label
                                        style="padding-left: 10px"><?php echo e(trans('messages.inactive')); ?></label>
                                    <br>
                                </div>
                                <div class="form-group mb-2">
                                    <label
                                        style="padding-left: 10px"><?php echo e(trans('messages.store')); ?> <?php echo e(trans('messages.id')); ?> </label><br>
                                    <input type="text" class="form-control" name="store_id"
                                           value="<?php echo e(env('APP_MODE')!='demo'?$config['store_id']:''); ?>">
                                </div>
                                <div class="form-group mb-2">
                                    <label
                                        style="padding-left: 10px"><?php echo e(trans('messages.store')); ?> <?php echo e(trans('messages.password')); ?></label><br>
                                    <input type="text" class="form-control" name="store_password"
                                           value="<?php echo e(env('APP_MODE')!='demo'?$config['store_password']:''); ?>">
                                </div>
                                <button type="<?php echo e(env('APP_MODE')!='demo'?'submit':'button'); ?>"
                                        onclick="<?php echo e(env('APP_MODE')!='demo'?'':'call_demo()'); ?>"
                                        class="btn btn-primary mb-2"><?php echo e(trans('messages.save')); ?></button>
                            <?php else: ?>
                                <button type="submit"
                                        class="btn btn-primary mb-2"><?php echo e(trans('messages.configure')); ?></button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body" style="padding: 20px">
                        <h5 class="text-center"><?php echo e(trans('messages.razorpay')); ?></h5>
                        <?php ($config=\App\CentralLogics\Helpers::get_business_settings('razor_pay')); ?>
                        <form
                            action="<?php echo e(env('APP_MODE')!='demo'?route('admin.business-settings.payment-method-update',['razor_pay']):'javascript:'); ?>"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($config)): ?>
                                <div class="form-group mb-2">
                                    <label class="control-label"><?php echo e(trans('messages.razorpay')); ?></label>
                                </div>
                                <div class="form-group mb-2 mt-2">
                                    <input type="radio" name="status" value="1" <?php echo e($config['status']==1?'checked':''); ?>>
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.active')); ?></label>
                                    <br>
                                </div>
                                <div class="form-group mb-2">
                                    <input type="radio" name="status" value="0" <?php echo e($config['status']==0?'checked':''); ?>>
                                    <label
                                        style="padding-left: 10px"><?php echo e(trans('messages.inactive')); ?></label>
                                    <br>
                                </div>
                                <div class="form-group mb-2">
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.razorkey')); ?></label><br>
                                    <input type="text" class="form-control" name="razor_key"
                                           value="<?php echo e(env('APP_MODE')!='demo'?$config['razor_key']:''); ?>">
                                </div>
                                <div class="form-group mb-2">
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.razorsecret')); ?></label><br>
                                    <input type="text" class="form-control" name="razor_secret"
                                           value="<?php echo e(env('APP_MODE')!='demo'?$config['razor_secret']:''); ?>">
                                </div>
                                <button type="<?php echo e(env('APP_MODE')!='demo'?'submit':'button'); ?>"
                                        onclick="<?php echo e(env('APP_MODE')!='demo'?'':'call_demo()'); ?>"
                                        class="btn btn-primary mb-2"><?php echo e(trans('messages.save')); ?></button>
                            <?php else: ?>
                                <button type="submit"
                                        class="btn btn-primary mb-2"><?php echo e(trans('messages.configure')); ?></button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body" style="padding: 20px">
                        <h5 class="text-center"><?php echo e(trans('messages.paypal')); ?></h5>
                        <?php ($config=\App\CentralLogics\Helpers::get_business_settings('paypal')); ?>
                        <form
                            action="<?php echo e(env('APP_MODE')!='demo'?route('admin.business-settings.payment-method-update',['paypal']):'javascript:'); ?>"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($config)): ?>
                                <div class="form-group mb-2">
                                    <label class="control-label"><?php echo e(trans('messages.paypal')); ?></label>
                                </div>
                                <div class="form-group mb-2 mt-2">
                                    <input type="radio" name="status" value="1" <?php echo e($config['status']==1?'checked':''); ?>>
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.active')); ?></label>
                                    <br>
                                </div>
                                <div class="form-group mb-2">
                                    <input type="radio" name="status" value="0" <?php echo e($config['status']==0?'checked':''); ?>>
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.inactive')); ?></label>
                                    <br>
                                </div>
                                <div class="form-group mb-2">
                                    <label
                                        style="padding-left: 10px"><?php echo e(trans('messages.paypal')); ?> <?php echo e(trans('messages.client')); ?> <?php echo e(trans('messages.id')); ?></label><br>
                                    <input type="text" class="form-control" name="paypal_client_id"
                                           value="<?php echo e(env('APP_MODE')!='demo'?$config['paypal_client_id']:''); ?>">
                                </div>
                                <div class="form-group mb-2">
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.paypalsecret')); ?> </label><br>
                                    <input type="text" class="form-control" name="paypal_secret"
                                           value="<?php echo e(env('APP_MODE')!='demo'?$config['paypal_secret']:''); ?>">
                                </div>
                                <button type="<?php echo e(env('APP_MODE')!='demo'?'submit':'button'); ?>"
                                        onclick="<?php echo e(env('APP_MODE')!='demo'?'':'call_demo()'); ?>"
                                        class="btn btn-primary mb-2"><?php echo e(trans('messages.save')); ?></button>
                            <?php else: ?>
                                <button type="submit"
                                        class="btn btn-primary mb-2"><?php echo e(trans('messages.configure')); ?></button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6 pt-4">
                <div class="card">
                    <div class="card-body" style="padding: 20px">
                        <h5 class="text-center"><?php echo e(trans('messages.stripe')); ?></h5>
                        <?php ($config=\App\CentralLogics\Helpers::get_business_settings('stripe')); ?>
                        <form action="<?php echo e(env('APP_MODE')!='demo'?route('admin.business-settings.payment-method-update',['stripe']):'javascript:'); ?>"
                              method="post">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($config)): ?>
                                <div class="form-group mb-2">
                                    <label class="control-label"><?php echo e(trans('messages.stripe')); ?></label>
                                </div>
                                <div class="form-group mb-2 mt-2">
                                    <input type="radio" name="status" value="1" <?php echo e($config['status']==1?'checked':''); ?>>
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.active')); ?></label>
                                    <br>
                                </div>
                                <div class="form-group mb-2">
                                    <input type="radio" name="status" value="0" <?php echo e($config['status']==0?'checked':''); ?>>
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.inactive')); ?> </label>
                                    <br>
                                </div>
                                <div class="form-group mb-2">
                                    <label
                                        style="padding-left: 10px"><?php echo e(trans('messages.published')); ?> <?php echo e(trans('messages.key')); ?></label><br>
                                    <input type="text" class="form-control" name="published_key"
                                           value="<?php echo e(env('APP_MODE')!='demo'?$config['published_key']:''); ?>">
                                </div>

                                <div class="form-group mb-2">
                                    <label
                                        style="padding-left: 10px"><?php echo e(trans('messages.api')); ?> <?php echo e(trans('messages.key')); ?></label><br>
                                    <input type="text" class="form-control" name="api_key"
                                           value="<?php echo e(env('APP_MODE')!='demo'?$config['api_key']:''); ?>">
                                </div>
                                <button type="<?php echo e(env('APP_MODE')!='demo'?'submit':'button'); ?>" onclick="<?php echo e(env('APP_MODE')!='demo'?'':'call_demo()'); ?>" class="btn btn-primary mb-2"><?php echo e(trans('messages.save')); ?></button>
                            <?php else: ?>
                                <button type="submit"
                                        class="btn btn-primary mb-2"><?php echo e(trans('messages.configure')); ?></button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6 pt-4">
                <div class="card">
                    <div class="card-body" style="padding: 20px">
                        <h5 class="text-center"><?php echo e(trans('messages.senang')); ?> <?php echo e(trans('messages.pay')); ?></h5>
                        <?php ($config=\App\CentralLogics\Helpers::get_business_settings('senang_pay')); ?>
                        <form action="<?php echo e(env('APP_MODE')!='demo'?route('admin.business-settings.payment-method-update',['senang_pay']):'javascript:'); ?>"
                              method="post">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($config)): ?>
                                <div class="form-group mb-2">
                                    <label class="control-label"><?php echo e(trans('messages.senang')); ?> <?php echo e(trans('messages.pay')); ?></label>
                                </div>
                                <div class="form-group mb-2 mt-2">
                                    <input type="radio" name="status" value="1" <?php echo e($config['status']==1?'checked':''); ?>>
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.active')); ?></label>
                                    <br>
                                </div>
                                <div class="form-group mb-2">
                                    <input type="radio" name="status" value="0" <?php echo e($config['status']==0?'checked':''); ?>>
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.inactive')); ?> </label>
                                    <br>
                                </div>
                                <div class="form-group mb-2">
                                    <label
                                        style="padding-left: 10px"><?php echo e(trans('messages.secret')); ?> <?php echo e(trans('messages.key')); ?></label><br>
                                    <input type="text" class="form-control" name="secret_key"
                                           value="<?php echo e(env('APP_MODE')!='demo'?$config['secret_key']:''); ?>">
                                </div>

                                <div class="form-group mb-2">
                                     <label
                                        style="padding-left: 10px"><?php echo e(trans('messages.merchant')); ?> <?php echo e(trans('messages.id')); ?></label><br>
                                    <input type="text" class="form-control" name="merchant_id"
                                           value="<?php echo e(env('APP_MODE')!='demo'?$config['merchant_id']:''); ?>">
                                </div>
                                <button type="<?php echo e(env('APP_MODE')!='demo'?'submit':'button'); ?>" onclick="<?php echo e(env('APP_MODE')!='demo'?'':'call_demo()'); ?>" class="btn btn-primary mb-2"><?php echo e(trans('messages.save')); ?></button>
                            <?php else: ?>
                                <button type="submit"
                                        class="btn btn-primary mb-2"><?php echo e(trans('messages.configure')); ?></button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6" style="margin-top: 26px!important;">
                <div class="card">
                    <div class="card-body" style="padding: 20px">
                        <h5 class="text-center"><?php echo e(trans('messages.paystack')); ?></h5>
                        <?php ($config=\App\CentralLogics\Helpers::get_business_settings('paystack')); ?>
                        <form
                            action="<?php echo e(env('APP_MODE')!='demo'?route('admin.business-settings.payment-method-update',['paystack']):'javascript:'); ?>"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($config)): ?>
                                <div class="form-group mb-2">
                                    <label class="control-label"><?php echo e(trans('messages.paystack')); ?></label>
                                </div>
                                <div class="form-group mb-2 mt-2">
                                    <input type="radio" name="status" value="1" <?php echo e($config['status']==1?'checked':''); ?>>
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.active')); ?></label>
                                    <br>
                                </div>
                                <div class="form-group mb-2">
                                    <input type="radio" name="status" value="0" <?php echo e($config['status']==0?'checked':''); ?>>
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.inactive')); ?></label>
                                    <br>
                                </div>
                                <div class="form-group mb-2">
                                    <label
                                        style="padding-left: 10px"><?php echo e(trans('messages.publicKey')); ?></label><br>
                                    <input type="text" class="form-control" name="publicKey"
                                           value="<?php echo e(env('APP_MODE')!='demo'?$config['publicKey']:''); ?>">
                                </div>
                                <div class="form-group mb-2">
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.secretKey')); ?> </label><br>
                                    <input type="text" class="form-control" name="secretKey"
                                           value="<?php echo e(env('APP_MODE')!='demo'?$config['secretKey']:''); ?>">
                                </div>
                                <div class="form-group mb-2">
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.paymentUrl')); ?> </label><br>
                                    <input type="text" class="form-control" name="paymentUrl"
                                           value="<?php echo e(env('APP_MODE')!='demo'?$config['paymentUrl']:''); ?>">
                                </div>
                                <div class="form-group mb-2">
                                    <label style="padding-left: 10px"><?php echo e(trans('messages.merchantEmail')); ?> </label><br>
                                    <input type="text" class="form-control" name="merchantEmail"
                                           value="<?php echo e(env('APP_MODE')!='demo'?$config['merchantEmail']:''); ?>">
                                </div>
                                <button type="<?php echo e(env('APP_MODE')!='demo'?'submit':'button'); ?>"
                                        onclick="<?php echo e(env('APP_MODE')!='demo'?'':'call_demo()'); ?>"
                                        class="btn btn-primary mb-2"><?php echo e(trans('messages.save')); ?></button>
                            <?php else: ?>
                                <button type="submit"
                                        class="btn btn-primary mb-2"><?php echo e(trans('messages.configure')); ?></button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/grofresh/resources/views/admin-views/business-settings/payment-index.blade.php ENDPATH**/ ?>